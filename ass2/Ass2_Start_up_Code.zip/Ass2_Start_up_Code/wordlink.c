/****************************************************************************
* COSC2138/CPT220 - Programming Principles 2A
* SP2 2015 Assignment #2 - word link program
* Full Name        : EDIT HERE
* Student Number   : EDIT HERE
* 
* Start up code provided by the C Teaching Team
****************************************************************************/

#include "wordlink.h"
#include "wordlink_options.h"
#include "wordlink_utility.h"

int main(int argc, char* argv[])
{
   DictionaryType dictionary;



   return EXIT_SUCCESS;
}
